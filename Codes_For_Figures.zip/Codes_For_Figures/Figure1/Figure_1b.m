clear
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%% Author: Yizhou Liu   (  yizhou.liu@weizmann.ac.il )                 %%%
%%%         (Weizmann Institute of Science)                             %%%
%%% This MatLab script calculates the chiral band structure and obtital %%%
%%% texture in chiral DNA-like materials by a tight-binding model       %%%
%%%                                                                     %%%
%%% Anyone who use this script in paraperation for a manuscript are     %%%
%%% recommended to cite:                                                %%%
%%% Y. Liu, J. Xiao, J. Koo, and B. Yan,                                %%%
%%% Chirality driven topological electronic structure of DNA-like materials
%%% arXiv:2008.08881, 2020.                                             %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% input parameters 
N=3;               % number of atoms within one helical unit cell
L_SOC=1;           % number of sites of SOC atoms
L_chiral=2;        % number of helical unit cells


bond=1;            % length of nearest neighbor bond between chiral atoms 
                   % projected in xy plane
                   
delta_z=1;         % projected bond length along z-axis

chirality=1;       % +1 (-1) for right- (left-) handedness

pp_sigma_C=1.5;    % chiral molecule sigma hopping
pp_pi_C=-0.5;      % chiral molecule pi hopping


SOC_chiral=0;      % SOC in the chiral molecule


Bfield_C_chiral=0; % Magnetic moment in chiral molecule



%%%%%%%%%%%%%%%%%%%%%%%%
% end input parameters %
%%%%%%%%%%%%%%%%%%%%%%%%


%% Constructing tight-binding Hamiltonian
Radius=bond/2/sin(pi/N);

Cross=N/2*Radius^2*sin(2*pi/N);


phi=0;       % magnetic flux induced complex phase of hopping in chiral molecule


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% constructing atomic coordinates of chiral molecule %%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
iatom=1;                                                                %%%
coordinate=zeros(N*L_chiral+1,3);                                       %%%
for iL=1:L_chiral                                                       %%%
    for iN=1:N                                                          %%%
        theta=2*pi/N*(iN-1)*chirality;                                  %%%
        x = Radius*cos(theta);                                          %%%
        y = Radius*sin(theta);                                          %%%
        z = (iatom-1)*delta_z;                                          %%%
        coordinate(iatom,:)=[x,y,z];                                    %%%
        iatom=iatom+1;                                                  %%%
    end                                                                 %%%
end                                                                     %%%
coordinate(N*L_chiral+1,:)=[Radius*cos(theta+2*pi/N*chirality),...      %%%
    Radius*sin(theta+2*pi/N*chirality),N*L_chiral*delta_z];             %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% spin and orbital angular momentum (AM) %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% matrix in basis of pxyz orbitals %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
l0=eye(3);                                                              %%%
lz=[0,-1i,0;...                                                         %%%
   1i, 0 ,0;...                                                         %%%
   0 , 0 ,0];                                                           %%%
lx=[0,0,0;...                                                           %%%
    0,0,-1i;...                                                         %%%
    0,1i,0];                                                            %%%
ly=[0,0,1i;...                                                          %%%
    0,0,0;...                                                           %%%
   -1i,0,0];                                                            %%%
                                                                        %%%
s0=eye(2);                                                              %%%
sz=[1,0;0,-1];                                                          %%%
sx=[0,1;1,0];                                                           %%%
sy=[0,-1i;1i,0];                                                        %%%
                                                                        %%%
L0=kron(l0,s0);                                                         %%%
Lx=kron(lx,s0);                                                         %%%
Ly=kron(ly,s0);                                                         %%%
Lz=kron(lz,s0);                                                         %%%
                                                                        %%%
S0=kron(l0,s0);                                                         %%%
Sx=kron(l0,sx);                                                         %%%
Sy=kron(l0,sy);                                                         %%%
Sz=kron(l0,sz);                                                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% SOC Hamiltonian in pxyz basis %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hsoc=[0*s0 -1i*sz  1i*sy;...                                            %%%
     1i*sz   0*s0 -1i*sx;...                                            %%%
    -1i*sy  1i*sx   0*s0];                                              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%% chiral molecule Hamiltonian for intra and inter unit cell %%%%%%%%%
%%%%%%% used for band structure calculation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                                        %%%
                                                                        %%%
%%%%%%%%%%%%%%%%%%%%%%% intra unit cell %%%%%%%%%%%%%%%%%%%%%%%%%%%%%   %%%
h_chiral=zeros(6*N,6*N);                                            %   %%%
for iatom=1:(N-1)                                                   %   %%%
    index1=6*(iatom-1)+1:6*(iatom);                                 %   %%%
    index2=6*(iatom)+1:6*(iatom+1);                                 %   %%%
                                                                    %   %%%
    vector12=coordinate(iatom+1,:)-coordinate(iatom,:);             %   %%%
    h_chiral(index1,index2)=...                                     %   %%%
        mk_h(pp_sigma_C*exp(1i*phi),pp_pi_C*exp(1i*phi),vector12);  %   %%%
    h_chiral(index2,index1)=...                                     %   %%%
        mk_h(pp_sigma_C*exp(-1i*phi),pp_pi_C*exp(-1i*phi),vector12);%   %%%
    h_chiral(index2,index2)=...                                     %   %%%
        Bfield_C_chiral*(Sz/2+Lz)+SOC_chiral*hsoc;                  %   %%%
end                                                                 %   %%%
h_chiral(1:6,1:6)=Bfield_C_chiral*(Sz/2+Lz)+SOC_chiral*hsoc;        %   %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   %%%
                                                                        %%%
                                                                        %%%
%%%%%%%%%%%%%%%%%%%%%% inter unit cell %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   %%%
V_chiral=zeros(6*N,6*N);                                            %   %%%
V_chiral(6*N-5:6*N,1:6)=...                                         %   %%%
    mk_h(pp_sigma_C*exp(1i*phi),pp_pi_C*exp(1i*phi),...             %   %%%
    coordinate(N+1,:)-coordinate(N,:));                             %   %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   %%%
                                                                        %%% 
                                                                        %%%
%%%%%%%%%% calculating band structure of chiral molecule %%%%%%%%%%%%   %%%
Kz_chiral=linspace(-pi,pi,1000);                                    %   %%%
[Ek_chiral,Lz_chiral,Psik_chiral]=...                               %   %%%
    chiral_bands(Kz_chiral,h_chiral,V_chiral);                      %   %%%
                                                                    %   %%%
% Ek_chiral: band dispersion relation                               %   %%%
% Lz_chiral: orbital AM Lz distribution in k-space                  %   %%%
% Psik_chiral: periodic part of wavefunction                        %   %%%
                                                                    %   %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   %%%
                                                                        %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% plot chiral band and orbital textures
figure
hold on
for iband=1:size(Ek_chiral,2)
    scatter(Kz_chiral/pi,Ek_chiral(:,iband),1,real(Lz_chiral(:,iband)))
end
caxis([min(min(real(Lz_chiral))),max(max(real(Lz_chiral)))])
colormap(jet)
colorbar
ylim([-2.5 2.5])
ylabel('Energy')
title('Chiral band')
xticks([-1 0 1])
xticklabels({'-Z','\Gamma','Z'})
xlabel('k_z')




%% functions used in this code

function h = mk_h(pps,ppp,v)

e=v/sqrt(v*v');

x=e(1);
y=e(2);
z=e(3);

hs = pps*[x^2, x*y, x*z;...
          y*x, y^2, y*z;...
          z*x, z*y, z*z];
hp = ppp*[1-x^2, -x*y, -x*z;...
           -y*x,1-y^2, -y*z;...
           -z*x, -z*y,1-z^2];
h = hs + hp;

h = kron(h,eye(2));

end


function [Ek,Lzk,Psik]=chiral_bands(Kz,h_chiral,V_chiral)

lz=zeros(3);lz(1,2)=-1i;lz(2,1)=1i;
lz=kron(lz,eye(2));

Nsite=size(h_chiral,1)/6;

Lz=kron(eye(Nsite),lz);

Ek=zeros(length(Kz),length(h_chiral));
Lzk=Ek;
Psik=zeros(length(h_chiral),length(h_chiral),length(Kz));
for ik=1:length(Kz)
    kz=Kz(ik);
    Hk=h_chiral+V_chiral*exp(1i*kz)+V_chiral'*exp(-1i*kz);
    [U,O]=eig(Hk);
    [Ek(ik,:),index]=sort(real(diag(O)));
    for n=1:length(index)
        Lzk(ik,n)=U(:,index(n))'*Lz*U(:,index(n));
        Psik(:,n,ik)=U(:,index(n));
    end
end

end








