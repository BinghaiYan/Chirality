clear
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%% Author: Yizhou Liu   (  yizhou.liu@weizmann.ac.il )                 %%%
%%%         (Weizmann Institute of Science)                             %%%
%%% This MatLab script calculates the chirality induced spin/orbital/   %%%
%%% total conductance in chiral DNA-like materials by both the          %%%
%%% nonequilibrium Green's Functions (NEFG) and scattering matrix methods%%
%%% binding method                                                      %%%
%%%                                                                     %%%
%%% Any usage of adaptation this script in paraperation for some        %%%
%%% manuscript are recommended to cite:                                 %%%
%%% Y. Liu, J. Xiao, J. Koo, and B. Yan,                                %%%
%%% Chirality driven topological electronic structure of DNA-like materials
%%% arXiv:2008.08881, 2020.                                             %%%
%%%                                                                     %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% input parameters 
N=3;               % number of atoms within one helical unit cell
L_SOC=1;           % number of sites of SOC atoms
L_CHIRAL=(1:12)';  % number of atoms in the chiral molecule

SOC_nonchiral=1;   % strength of SOC atoms 


eta0=1e-10;        % dephasing parameter in the lead

eta=1e-10;         % dephasing parameter in the chiral molecule


bond=1;            % length of nearest neighbor bond between chiral atoms 
                   % projected in xy plane
                   
delta_z=1;         % projected bond length along z-axis

chirality=1;       % +1 (-1) for right- (left-) handedness

pp_sigma_L=1.6;    % left lead sigma hopping amplitude
pp_pi_L=-2.4;      % left lead pi hopping amplitude

pp_sigma_R=pp_sigma_L;  % right lead sigma hopping
pp_pi_R=pp_pi_L;        % right lead pi hopping

pp_sigma_C=1.5;    % chiral molecule sigma hopping
pp_pi_C=-0.5;      % chiral molecule pi hopping

pp_sigma_interface=1;  % sigma hopping between SOC atoms and leads
pp_pi_interface=-1.5;  % pi hopping between SOC atoms and leads

SOC_L=0;           % SOC in left lead
SOC_R=0;           % SOC in right lead
SOC_chiral=0;      % SOC in the chiral molecule

Bfield_L=0.000001; % Magnetic moment in left lead
Bfield_R=Bfield_L; % Magnetic moment in right lead
Bfield_C_chiral=0; % Magnetic moment in chiral molecule
Bfield_C_SOC=0;    % Magnetic moment in SOC atoms

Energy=[-1.728,1.728]; % position of peak 1 and 2


%%%%%%%%%%%%%%%%%%%%%%%%
% end input parameters %
%%%%%%%%%%%%%%%%%%%%%%%%


%% Constructing Hamiltonian and calculating spin polarization


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% spin and orbital angular momentum (AM) %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% matrix in basis of pxyz orbitals %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
l0=eye(3);                                                              %%%
lz=[0,-1i,0;...                                                         %%%
   1i, 0 ,0;...                                                         %%%
   0 , 0 ,0];                                                           %%%
lx=[0,0,0;...                                                           %%%
    0,0,-1i;...                                                         %%%
    0,1i,0];                                                            %%%
ly=[0,0,1i;...                                                          %%%
    0,0,0;...                                                           %%%
   -1i,0,0];                                                            %%%
                                                                        %%%
s0=eye(2);                                                              %%%
sz=[1,0;0,-1];                                                          %%%
sx=[0,1;1,0];                                                           %%%
sy=[0,-1i;1i,0];                                                        %%%
                                                                        %%%
L0=kron(l0,s0);                                                         %%%
Lx=kron(lx,s0);                                                         %%%
Ly=kron(ly,s0);                                                         %%%
Lz=kron(lz,s0);                                                         %%%
                                                                        %%%
S0=kron(l0,s0);                                                         %%%
Sx=kron(l0,sx);                                                         %%%
Sy=kron(l0,sy);                                                         %%%
Sz=kron(l0,sz);                                                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% SOC Hamiltonian in pxyz basis %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hsoc=[0*s0 -1i*sz  1i*sy;...                                            %%%
     1i*sz   0*s0 -1i*sx;...                                            %%%
    -1i*sy  1i*sx   0*s0];                                              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%






H00_L=Bfield_L*Sz+0.00001*(Sz/2+Lz)+SOC_L*hsoc;   % onsite Hamiltonian of 
                                                  % left lead
                                                  
H01_L=mk_h(pp_sigma_L,pp_pi_L,[0,0,-1]);          % intersite Hamiltonian 
                                                  % of left lead
                                                  
H00_R=Bfield_R*Sz+0.00001*(Sz/2+Lz)+SOC_R*hsoc;   % onsite Hamiltonian of
                                                  % right lead
                                                  
H01_R=mk_h(pp_sigma_R,pp_pi_R,[0,0,1]);           % intersite Hamiltonian
                                                  % of right lead

for iLchiral=1:length(L_CHIRAL)
    disp(['Calculating transmissions for increasing number of chiral atoms: ',...
        num2str(iLchiral/length(L_CHIRAL)*100),'% ...'])
    
    L_chiral_site=L_CHIRAL(iLchiral);
    % -------- make up Hamiltonian of whole scattering region -------------
    HC=mk_HC(L_chiral_site,L_SOC,SOC_nonchiral,bond,delta_z,N,...
        pp_sigma_C,pp_pi_C,pp_sigma_interface,pp_pi_interface,chirality,...
        Bfield_C_SOC,Bfield_C_chiral);
    
    VCL=zeros(size(HC,1),6);
    VCL(1:6,:)=H01_L;
    
    VCR=zeros(size(HC,1),6);
    VCR(size(HC,1)-5:size(HC,1),:)=H01_R;
    
    for iE=1:length(Energy)
        E=Energy(iE);
        % -------- get surface retarded GF of Left lead -----------
        [gsr_L,gbr_L]=...
            surfGF_H(E,H00_L,H00_L,H01_L,H01_L',eye(size(H00_L)),200,eta0);
        
        % -------- get surface retarded GF of right lead ----------
        [gsr_R,gbr_R]=...
            surfGF_H(E,H00_L,H00_L,H01_L',H01_L,eye(size(H00_L)),200,eta0);
        
        [t,r,u_L_p,u_L_m,u_R_p,u_R_m]=...
            mk_t_matrix(E,H01_L,H00_L,H01_R,H00_R,...
            HC,VCL,VCR,gsr_L,gsr_R,gbr_L,gbr_R,eta);
        
        % t: the complex transmission amplitude matrix
        % r: the complex reflection amplitude matrix
        % u_L_p: normalized wavefunctions in the left lead with positive 
        %        group velocities
        % u_L_m: normalized wavefunctions in the left lead with negative 
        %        group velocities
        % u_R_p: normalized wavefunctions in the right lead with positive 
        %        group velocities
        % u_R_m: normalized wavefunctions in the right lead with negative 
        %        group velocities
        
        Xi(iLchiral,iE)=trace(t'*t);  % total transmission 
        
        if ~isempty(u_L_p) && ~isempty(u_R_p)
            Sxnm=u_L_p'*Sx*u_L_p;
            Synm=u_L_p'*Sy*u_L_p;
            Sznm=u_L_p'*Sz*u_L_p;
            
            Lxnm=u_L_p'*Lx*u_L_p;
            Lynm=u_L_p'*Ly*u_L_p;
            Lznm=u_L_p'*Lz*u_L_p;
            
            Xi_Sx(iLchiral,iE)=trace(t'*diag(diag(Sxnm))*t);
            Xi_Sy(iLchiral,iE)=trace(t'*diag(diag(Synm))*t);
            Xi_Sz(iLchiral,iE)=trace(t'*diag(diag(Sznm))*t);
            Xi_Lx(iLchiral,iE)=trace(t'*diag(diag(Lxnm))*t);
            Xi_Ly(iLchiral,iE)=trace(t'*diag(diag(Lynm))*t);
            Xi_Lz(iLchiral,iE)=trace(t'*diag(diag(Lznm))*t);
        end
    end
end

PSx=Xi_Sx./Xi;
PSy=Xi_Sy./Xi;
PSz=Xi_Sz./Xi;



%% plot spin polarization as function of number of atoms in chiral chain
figure
hold on
scatter(L_CHIRAL,real(PSz(:,1)),'ob')
scatter(L_CHIRAL,real(PSz(:,2)),'or')
plot(L_CHIRAL,real(PSz(:,1)),'--b')
plot(L_CHIRAL,real(PSz(:,2)),'--r')
legend('Peak 1','Peak2')
xlabel('Energy')
ylabel('P_{S_z}')








%% functions used in this code

function HC = mk_HC(L_chiral_site,L_SOC,SOC_nonchiral,bond,delta_z,N,...
    pp_sigma_C,pp_pi_C,pp_sigma_interface,pp_pi_interface,chirality,...
    Bfield_C_SOC,Bfield_C_chiral)

Radius=bond/2/sin(pi/N);

% Cross=N/2*Radius^2*sin(2*pi/N);

l0=eye(3);
lz=[0,-1i,0;...
   1i, 0 ,0;...
   0 , 0 ,0];
lx=[0,0,0;...
    0,0,-1i;...
    0,1i,0];
ly=[0,0,1i;...
    0,0,0;...
   -1i,0,0];

s0=eye(2);
sz=[1,0;0,-1];
sx=[0,1;1,0];
sy=[0,-1i;1i,0];

L0=kron(l0,s0);
Lx=kron(lx,s0);
Ly=kron(ly,s0);
Lz=kron(lz,s0);

S0=kron(l0,s0);
Sx=kron(l0,sx);
Sy=kron(l0,sy);
Sz=kron(l0,sz);

hsoc=[0*s0 -1i*sz  1i*sy;...
     1i*sz   0*s0 -1i*sx;...
    -1i*sy  1i*sx   0*s0];

% phi=1/3*Bfield_C_chiral*Cross;
phi=0;

iatom=1;
coordinate=zeros(L_chiral_site,3);
for iL=1:L_chiral_site
    theta=2*pi/N*(iL-1)*chirality;
    x = Radius*cos(theta);
    y = Radius*sin(theta);
    z = (iatom-1)*delta_z;
    coordinate(iatom,:)=[x,y,z];
    iatom=iatom+1;
end
% coordinate(N*L_chiral+1,:)=[Radius*cos(theta+2*pi/N*chirality),...
%     Radius*sin(theta+2*pi/N*chirality),N*L_chiral*delta_z];

% EE=linspace(EL,ER,N*(L_SOC+L_chiral)+2);
% E_onsite=EE(2:length(EE)-1);
% E_onsite_SOC=EE(1:N*L_SOC);
% E_onsite_chiral=EE(N*L_SOC+1:N*(L_SOC+L_chiral));

HC_chiral=zeros(L_chiral_site*6);
for iatom =1:(L_chiral_site-1)
    index1=6*(iatom-1)+1:6*(iatom);
    index2=6*(iatom)+1:6*(iatom+1);
    
%     E_onsite_index2=(ER-EL)/(N*L_chiral-1)*iatom;
    
    vector12=coordinate(iatom+1,:)-coordinate(iatom,:);
    HC_chiral(index1,index2)=...
        mk_h(pp_sigma_C*exp(1i*phi),pp_pi_C*exp(1i*phi),vector12);
    HC_chiral(index2,index1)=...
        mk_h(pp_sigma_C*exp(-1i*phi),pp_pi_C*exp(-1i*phi),vector12);
    HC_chiral(index2,index2)=Bfield_C_chiral*Sz/2;
end
% HC_chiral(1:6,1:6)=E_onsite_chiral(1)*eye(6);

HC_SOC=zeros(L_SOC*6);
for iatom =1:L_SOC-1
    index1=6*(iatom-1)+1:6*(iatom);
    index2=6*(iatom)+1:6*(iatom+1);
    
    HC_SOC(index1,index2)=mk_h(pp_sigma_interface,pp_pi_interface,[0,0,1]);
    HC_SOC(index2,index1)=mk_h(pp_sigma_interface,pp_pi_interface,[0,0,1]);
    HC_SOC(index2,index2)=SOC_nonchiral*hsoc+Bfield_C_SOC*(Sz/2);
end
HC_SOC(1:6,1:6)=SOC_nonchiral*hsoc+Bfield_C_SOC*(Sz/2);

HC_SOC_chiral=zeros(6*L_SOC,6*L_chiral_site);
HC_SOC_chiral(6*L_SOC-5:6*L_SOC,1:6)=...
    mk_h(pp_sigma_interface,pp_pi_interface,[0,0,1]);
HC_chiral_SOC=zeros(6*L_chiral_site,6*L_SOC);
HC_chiral_SOC(6*(L_chiral_site-1)+1:6*L_chiral_site,1:6)=...
    mk_h(pp_sigma_interface,pp_pi_interface,[0,0,1]);
HC_SOC_SOC=zeros(6*L_SOC,6*L_SOC);
HC=[HC_SOC,        HC_SOC_chiral, HC_SOC_SOC;...
    HC_SOC_chiral',HC_chiral,     HC_chiral_SOC;...
    HC_SOC_SOC',   HC_chiral_SOC',HC_SOC];

end


function [tnm,rnm,u_L_p,u_L_m,u_R_p,u_R_m]=mk_t_matrix(E,H01_L,H00_L,H01_R,H00_R,HC,VCL,VCR,gsr_L,gsr_R,gbr_L,gbr_R,eta)
    
    % ---------------- AL BL AR BR ---------------------
    [AL,BL,AR,BR]=mk_AB(E,H01_L,H00_L,H01_R,H00_R);
    % -------------- end AL BL AR BR -------------------
    
    
    
    % -------------- G_{S+1,0} -------------------------
    sigma_r_L=H01_L*gsr_L*H01_L';
    sigma_r_R=H01_R*gsr_R*H01_R';
    
    HLL=H00_L+sigma_r_L;
    HLC=VCL';
    HLR=zeros(size(H00_L,1),size(H00_R,2));
    
    HCL=VCL;
    HCC=HC;
    HCR=VCR;
    
    HRL=HLR';
    HRC=VCR';
    HRR=H00_R+sigma_r_R;
    
    H=[HLL,HLC,HLR;...
       HCL,HCC,HCR;...
       HRL,HRC,HRR];
    Wr_tot=(E+1i*eta)*eye(size(H))-H;
    Gr_tot=eye(size(Wr_tot))/Wr_tot;
    
    index_N=size(H,1)-5:size(H,1);
    index_0=1:6;
    
    GN0=Gr_tot(index_N,index_0);
    G00=Gr_tot(index_0,index_0);
    % ------------ end G_{S+1,0} -----------------------
    
    
    
    %---------------- lambda_L, lambda_R ----------------
    [UL,OL]=eig(AL,BL);
    [UR,OR]=eig(AR,BR);
    
    [lambda_L_p,v_L_p,u_L_p,lambda_L_m,v_L_m,u_L_m,uu_L_p,uu_L_m]...
        =mk_uvR(UL,OL,H01_L',eta);
    [lambda_R_p,v_R_p,u_R_p,lambda_R_m,v_R_m,u_R_m,uu_R_p,uu_R_m]...
        =mk_uvR(UR,OR,H01_R,eta);
    %
    
    %}
    
%     u_R=[u_R_p,u_R_m];
%     u_LL=[u1_LL,u2_LL];
%     uu_R_new=eye(length(v_R_p)+length(v_R_m))/u_R;
%     uu_LL_new=eye(length(v1_LL)+length(v2_LL))/u_LL;
    %-------------- end lambda_L, lambda_R -------------
    
    
    
    % --------------- Transmission --------------------
    if isempty(u_L_p)==1
        tnm=[];
        rnm=[];
    else
        tnm=zeros(length(v_L_p),length(v_R_p));
        rnm=zeros(length(v_L_p),length(v_L_m));
    
    for j=1:length(v_L_p)
        for k=1:length(v_R_p)
            tnm(j,k)=sqrt(v_R_p(k)/v_L_p(j))...
                *uu_R_p(k,:)*GN0/gbr_L*u_L_p(:,j);
        end
        
        for k=1:length(v_L_m)
            rnm(j,k)=sqrt(v_L_m(k)/v_L_p(j))...
                *uu_L_m(k,:)*(G00/gbr_L-eye(6))*u_L_p(:,j);
        end
    end
    end
    
    
end


function [AL,BL,AR,BR]=mk_AB(E,V_left,Hb_left,V_right,Hb_right)

ML=length(Hb_left);
MR=length(Hb_right);

AL=[V_left, Hb_left; zeros(ML), eye(ML)];
BL=[E*eye(ML), -V_left'; eye(ML), zeros(ML)];

AR=[V_right', Hb_right; zeros(MR), eye(MR)];
BR=[E*eye(MR), -V_right; eye(MR), zeros(MR)];

end


function [lambda_p,v_p,u_p,lambda_m,v_m,u_m]=mk_uv(U,O,V)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

u=U(1:length(U)/2,:);                    % get ui
% ------------- normalize ui ----------------
for i=1:length(u)
    u(:,i)=u(:,i)/sqrt(u(:,i)'*u(:,i));
end
% ---------- end normalize ui -------------

o=diag(O);
k=zeros(length(o),1);
v=zeros(length(o),1);

index_p1=[];
index_p2=[];
index_p=[];
index_m=[];

for i=1:length(o)
    if abs(abs(O(i))-1)<1e-5
        v(i)=-imag(o(i)*u(:,i)'*V*u(:,i));
        if v(i)>0 
            index_p=[index_p,i];
        end
        if v(i)<0
            index_m=[index_m,i];
        end
    end
end

if isempty(index_p)==0
lambda_p=o(index_p);
v_p=v(index_p);
for i=1:length(index_p)
    u_p(:,i)=u(:,index_p(i));
end
else 
    lambda_p=[];
    v_p=[];
    u_p=[];
end

if isempty(index_m)==0
lambda_m=o(index_m);
v_m=v(index_m);
for i=1:length(index_m)
    u_m(:,i)=u(:,index_m(i));
end
else
    lambda_m=[];
    v_m=[];
    u_m=[];
end

end


function [lambda_p,v_p,u_p,lambda_m,v_m,u_m,uu_p,uu_m]=mk_uvR(U,O,V,eta)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

u=U(1:length(U)/2,:);                    % get ui
% ------------- normalize ui ----------------
for i=1:length(u)
    u(:,i)=u(:,i)/sqrt(u(:,i)'*u(:,i));
end
% ---------- end normalize ui -------------

o=diag(O);
v=zeros(length(o),1);

index_p=[];
index_m=[];


for i=1:length(o)
    v(i)=-imag(o(i)*u(:,i)'*V*u(:,i));
    if abs(abs(o(i))-1)<eta && v(i)>0
        index_p=[index_p,i];
    end
end


for i=1:length(o)
    if abs(abs(o(i))-1)<eta && v(i)<0
        index_m=[index_m,i];
    end
end

if isempty(index_p)==0
lambda_p=o(index_p);
v_p=v(index_p);
for i=1:length(index_p)
    u_p(:,i)=u(:,index_p(i));
end
else
    lambda_p=[];
    v_p=[];
    u_p=[];
end

if isempty(index_m)==0
lambda_m=o(index_m);
v_m=v(index_m);
for i=1:length(index_m)
    u_m(:,i)=u(:,index_m(i));
end
else
    lambda_m=[];
    v_m=[];
    u_m=[];
end


uu_p=pinv(u_p);
uu_m=pinv(u_m);

end






function h = mk_h(pps,ppp,v)

e=v/sqrt(v*v');

x=e(1);
y=e(2);
z=e(3);

hs = pps*[x^2, x*y, x*z;...
          y*x, y^2, y*z;...
          z*x, z*y, z*z];
hp = ppp*[1-x^2, -x*y, -x*z;...
           -y*x,1-y^2, -y*z;...
           -z*x, -z*y,1-z^2];
h = hs + hp;

h = kron(h,eye(2));

end


function [ Gs,Gb ] = surfGF_H( omega,Hs,Hb,alpha,beta,A,p,q )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
[m,~]=size(Hs);
Ws0=(omega+q*1i)*A-Hs;
Wb0=(omega+q*1i)*A-Hb;
alpha0=alpha;
beta0=beta;

for i=1:p
    Ws1=Ws0-alpha0/Wb0*beta0;
    Wb1=Wb0-alpha0/Wb0*beta0-beta0/Wb0*alpha0;
    alpha1=alpha0/Wb0*alpha0;
    beta1=beta0/Wb0*beta0;
    
    Ws0=Ws1;
    Wb0=Wb1;
    alpha0=alpha1;
    beta0=beta1;
end

Gs=eye(m)/Ws1;
Gb=eye(m)/Wb1;

end


function [Ek,Lzk,Psik]=chiral_bands(Kz,h_chiral,V_chiral)

lz=zeros(3);lz(1,2)=-1i;lz(2,1)=1i;
lz=kron(lz,eye(2));

Nsite=size(h_chiral,1)/6;

Lz=kron(eye(Nsite),lz);

Ek=zeros(length(Kz),length(h_chiral));
Lzk=Ek;
Psik=zeros(length(h_chiral),length(h_chiral),length(Kz));
for ik=1:length(Kz)
    kz=Kz(ik);
    Hk=h_chiral+V_chiral*exp(1i*kz)+V_chiral'*exp(-1i*kz);
    [U,O]=eig(Hk);
    [Ek(ik,:),index]=sort(real(diag(O)));
    for n=1:length(index)
        Lzk(ik,n)=U(:,index(n))'*Lz*U(:,index(n));
        Psik(:,n,ik)=U(:,index(n));
    end
end

end


function [Ek,Lz] = chiral_bandstructure(Kz,N,coordinate,ppsigma,pppi,SOC)

Lambda=[
   -0.5000         0         0    0.7071         0         0
         0    0.5000         0         0         0         0
         0         0         0         0         0   -0.7071
    0.7071         0         0         0         0         0
         0         0         0         0    0.5000         0
         0         0   -0.7071         0         0   -0.5000]*SOC;

N_HAM=N*6;
nk=size(Kz,2);
Hc0=zeros(N_HAM/2,N_HAM/2);
Ek = zeros(N_HAM,nk);
Lz = zeros(N_HAM,nk);
tauz0=diag([1 1 0 0 -1 -1]);   % for the p+ pz  p- basis
tauz=kron(eye(N),tauz0);
deltaz=2;

for ikz=1:nk
    kz=Kz(ikz);
    for iatom = 1:N
        index=3*(iatom-1)+1;
        index2=3*(iatom)+1;
        if iatom ==N
            coordinate_end=coordinate(1,:);
            coordinate_end(3)=iatom*deltaz; % add the last atom
            tmp_vector = coordinate_end-coordinate(iatom,:);
        else
            tmp_vector = coordinate(iatom+1,:)-coordinate(iatom,:);
        end
        if iatom<N
            hopping = mk_hopping(ppsigma,pppi,tmp_vector);
            Hc0(index:index+2,index2:index2+2)=hopping*exp(-1i*kz/N);
            hopping = mk_hopping(ppsigma,pppi,-tmp_vector);
            Hc0(index2:index2+2,index:index+2)=hopping*exp(1i*kz/N);
        else
            index2=1;
            hopping = mk_hopping(ppsigma,pppi,tmp_vector);
            Hc0(index:index+2,index2:index2+2)=hopping*exp(-1i*kz/N);
            hopping = mk_hopping(ppsigma,pppi,-tmp_vector);
            Hc0(index2:index2+2,index:index+2)=hopping*exp(1i*kz/N);
        end
    end
    Hc0 = (Hc0 + Hc0')/2;
    Hc0_so = kron(Hc0,eye(2))+kron(eye(N),Lambda);
    
    [Wavek,Ektmp]=eig(Hc0_so);
    tmpE=diag(Ektmp)';
    Ek(:,ikz)=tmpE;
    Lz_matrix=Wavek'*tauz*Wavek;
    Lz(:,ikz) = diag(Lz_matrix)';
end
end


function Ek = lead_bandstructure(Kz,L00,L01)
N_HAM=size(L00,1);
nk=size(Kz,2);
Hc0=zeros(N_HAM,N_HAM);
Ek = zeros(N_HAM,nk);

for ikz=1:nk
    kz=Kz(ikz);
%     Hc0 = L00 + L01*cos(kz)*2;
    Hc0 = L00 + (L01*exp(1i*kz)+L01'*exp(-1i*kz));

    Hc0 = (Hc0+Hc0')/2;
    [Wavek,Ektmp]=eig(Hc0);
    tmpE=diag(Ektmp)';
    Ek(:,ikz)=tmpE;
end
end


function h = mk_hopping(pps,ppp,v)
% v is [x y z] vector, we use the direction cosine of the vector, (l m n)
e=v/sqrt(v*v');
l=e(1); m=e(2); n=e(3);
% the standard Slater-Koster hopping is as follows
hs = pps*[l^2, l*m, l*n;...
          m*l, m^2, m*n;...
          n*l, n*m, n*n];
hp = ppp*[1-l^2, -l*m, -l*n;...
           -m*l,1-m^2, -m*n;...
           -n*l, -n*m,1-n^2];
h0 = hs + hp;
% convert to basis: px+ipy, pz, px-ipy
R = [1   1i    0
     0   0    sqrt(2)
     1   -1i   0]/sqrt(2);
h = R*h0/R;
end





function Sigma0=mk_Sigma0_1(D0,E,HC,Sigma_r_L,Sigma_r_R)

Delta=100;

eta=1e-5;

% Sigma0_old=D0*GC0r;
Sigma0_old=zeros(size(HC));
while Delta>1e-6
    D0_matrix=D0*ones(size(HC));
    Sigma0_new=D0_matrix.*(eye(size(HC))/((E+1i*eta)*eye(size(HC))-HC-Sigma_r_L-Sigma_r_R-Sigma0_old));
    Delta=sum(sum(abs(Sigma0_new-Sigma0_old)));
    Sigma0_old=Sigma0_old+0.25*(Sigma0_new-Sigma0_old);
end
Sigma0=Sigma0_new;

end

function Sigma0=mk_Sigma0_2(D0,E,HC,Sigma_r_L,Sigma_r_R)

Delta=100;

eta=1e-5;

% Sigma0_old=D0*eye(size(HC)).*GC0r;
Sigma0_old=zeros(size(HC));
while Delta>1e-6
    D0_matrix=D0*eye(size(HC));
    Sigma0_new=D0_matrix.*(eye(size(HC))/((E+1i*eta)*eye(size(HC))-HC-Sigma_r_L-Sigma_r_R-Sigma0_old));
    Delta=sum(sum(abs(Sigma0_new-Sigma0_old)));
    Sigma0_old=Sigma0_old+0.25*(Sigma0_new-Sigma0_old);
end
Sigma0=Sigma0_new;

end

function Sigma0_in=mk_Sigma0_in_1(D0,GCr,GCa,fL,fR,Gamma_L,Gamma_R)

Delta=100;

eta=1e-5;

% Sigma0_in_old=D0*GCr*(fL*Gamma_L+fR*Gamma_R)*GCa;
Sigma0_in_old=zeros(size(GCr));
while Delta>1e-6
    D0_matrix=D0*ones(size(GCr));
    Sigma0_in_new=D0_matrix.*(GCr*(fL*Gamma_L+fR*Gamma_R+Sigma0_in_old)*GCa);
    Delta=sum(sum(abs(Sigma0_in_new-Sigma0_in_old)));
    Sigma0_in_old=Sigma0_in_old+0.25*(Sigma0_in_new-Sigma0_in_old);
end
Sigma0_in=Sigma0_in_new;

end

function Sigma0_in=mk_Sigma0_in_2(D0,GCr,GCa,fL,fR,Gamma_L,Gamma_R)

Delta=100;

% Sigma0_in_old=D0*eye(size(GCr)).*(GCr*(fL*Gamma_L+fR*Gamma_R)*GCa);
Sigma0_in_old=zeros(size(GCr));
while Delta>1e-6
    D0_matrix=D0*eye(size(GCr));
    Sigma0_in_new=D0_matrix.*(GCr*(fL*Gamma_L+fR*Gamma_R+Sigma0_in_old)*GCa);
    Delta=sum(sum(abs(Sigma0_in_new-Sigma0_in_old)));
    Sigma0_in_old=Sigma0_in_old+0.25*(Sigma0_in_new-Sigma0_in_old);
end
Sigma0_in=Sigma0_in_new;

end






