clear
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%% Author: Yizhou Liu   (  yizhou.liu@weizmann.ac.il )                 %%%
%%%         (Weizmann Institute of Science)                             %%%
%%% This MatLab script calculates the chirality induced spin/orbital/   %%%
%%% total conductance in chiral DNA-like materials by both the          %%%
%%% nonequilibrium Green's Functions (NEFG) and scattering matrix methods%%
%%% binding method                                                      %%%
%%%                                                                     %%%
%%% Any usage of adaptation this script in paraperation for some        %%%
%%% manuscript are recommended to cite:                                 %%%
%%% Y. Liu, J. Xiao, J. Koo, and B. Yan,                                %%%
%%% Chirality driven topological electronic structure of DNA-like materials
%%% arXiv:2008.08881, 2020.                                             %%%
%%%                                                                     %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%% input parameters 
N=3;               % number of atoms within one helical unit cell
L_SOC=1;           % number of sites of SOC atoms
L_chiral=2;        % number of helical unit cells

SOC_nonchiral=0.5; % strength of SOC atoms


eta0=1e-10;        % dephasing parameter in the lead

eta=0.01;          % dephasing parameter in the scattering region


bond=1;            % length of nearest neighbor bond between chiral atoms 
                   % projected in xy plane
                   
delta_z=1;         % projected bond length along z-axis

chirality=1;       % +1 (-1) for right- (left-) handedness

pp_sigma_L=1.6;    % left lead sigma hopping amplitude
pp_pi_L=-2.4;      % left lead pi hopping amplitude

pp_sigma_R=pp_sigma_L;  % right lead sigma hopping
pp_pi_R=pp_pi_L;        % right lead pi hopping

pp_sigma_C=1.5;    % chiral molecule sigma hopping
pp_pi_C=-0.5;      % chiral molecule pi hopping

pp_sigma_interface=1;  % sigma hopping between SOC atoms and leads
pp_pi_interface=-1.5;  % pi hopping between SOC atoms and leads

SOC_L=0;           % SOC in left lead
SOC_R=0;           % SOC in right lead
SOC_chiral=0;      % SOC in the chiral molecule

Bfield_L=[0,0,0.2,-0.2,0.4,-0.4,...% increasing Magnetic moment in left lead
    0.6,-0.6,0.8,-0.8,1.0,-1.0]; 
Bfield_R=Bfield_L;                % Magnetic moment in right lead
Bfield_C_chiral=0;                % Magnetic moment in chiral molecule
Bfield_C_SOC=0;                   % Magnetic moment in SOC atoms

% ----------- Energy range for conductance calculation -------------
nE=1251;
Emin=-2.5;
Emax=2.5;
Energy=linspace(Emin,Emax,nE);
% --------- end Energy range for conductance calculation -----------

%%%%%%%%%%%%%%%%%%%%%%%%
% end input parameters %
%%%%%%%%%%%%%%%%%%%%%%%%


%% Constructing tight-binding Hamiltonian
Radius=bond/2/sin(pi/N);

Cross=N/2*Radius^2*sin(2*pi/N);

% phi=1/3*Bfield_C_chiral*Cross;
phi=0;       % magnetic flux induced complex phase of hopping in chiral molecule


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% constructing atomic coordinates of chiral molecule %%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
iatom=1;                                                                %%%
coordinate=zeros(N*L_chiral+1,3);                                       %%%
for iL=1:L_chiral                                                       %%%
    for iN=1:N                                                          %%%
        theta=2*pi/N*(iN-1)*chirality;                                  %%%
        x = Radius*cos(theta);                                          %%%
        y = Radius*sin(theta);                                          %%%
        z = (iatom-1)*delta_z;                                          %%%
        coordinate(iatom,:)=[x,y,z];                                    %%%
        iatom=iatom+1;                                                  %%%
    end                                                                 %%%
end                                                                     %%%
coordinate(N*L_chiral+1,:)=[Radius*cos(theta+2*pi/N*chirality),...      %%%
    Radius*sin(theta+2*pi/N*chirality),N*L_chiral*delta_z];             %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% spin and orbital angular momentum (AM) %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% matrix in basis of pxyz orbitals %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
l0=eye(3);                                                              %%%
lz=[0,-1i,0;...                                                         %%%
   1i, 0 ,0;...                                                         %%%
   0 , 0 ,0];                                                           %%%
lx=[0,0,0;...                                                           %%%
    0,0,-1i;...                                                         %%%
    0,1i,0];                                                            %%%
ly=[0,0,1i;...                                                          %%%
    0,0,0;...                                                           %%%
   -1i,0,0];                                                            %%%
                                                                        %%%
s0=eye(2);                                                              %%%
sz=[1,0;0,-1];                                                          %%%
sx=[0,1;1,0];                                                           %%%
sy=[0,-1i;1i,0];                                                        %%%
                                                                        %%%
L0=kron(l0,s0);                                                         %%%
Lx=kron(lx,s0);                                                         %%%
Ly=kron(ly,s0);                                                         %%%
Lz=kron(lz,s0);                                                         %%%
                                                                        %%%
S0=kron(l0,s0);                                                         %%%
Sx=kron(l0,sx);                                                         %%%
Sy=kron(l0,sy);                                                         %%%
Sz=kron(l0,sz);                                                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% SOC Hamiltonian in pxyz basis %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hsoc=[0*s0 -1i*sz  1i*sy;...                                            %%%
     1i*sz   0*s0 -1i*sx;...                                            %%%
    -1i*sy  1i*sx   0*s0];                                              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% chiral molecule Hamiltonian %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% used for transport calculation %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
HC_chiral=zeros(6*(N*L_chiral+1));                                      %%%
for iatom =1:(N*L_chiral)                                               %%%
    index1=6*(iatom-1)+1:6*(iatom);                                     %%%
    index2=6*(iatom)+1:6*(iatom+1);                                     %%%
                                                                        %%%
    vector12=coordinate(iatom+1,:)-coordinate(iatom,:);                 %%%
    HC_chiral(index1,index2)=mk_h(pp_sigma_C,pp_pi_C,vector12);         %%%
    HC_chiral(index2,index1)=mk_h(pp_sigma_C,pp_pi_C,vector12);         %%%
    HC_chiral(index2,index2)=Bfield_C_chiral*(Sz/2+Lz)+SOC_chiral*hsoc; %%%
end                                                                     %%%
HC_chiral(1:6,1:6)=Bfield_C_chiral*(Sz/2+Lz)+SOC_chiral*hsoc;           %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%% chiral molecule Hamiltonian for intra and inter unit cell %%%%%%%%%
% %%%%%%% used for band structure calculation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %%%
%                                                                         %%%
% %%%%%%%%%%%%%%%%%%%%%%% intra unit cell %%%%%%%%%%%%%%%%%%%%%%%%%%%%%   %%%
% h_chiral=zeros(6*N,6*N);                                            %   %%%
% for iatom=1:(N-1)                                                   %   %%%
%     index1=6*(iatom-1)+1:6*(iatom);                                 %   %%%
%     index2=6*(iatom)+1:6*(iatom+1);                                 %   %%%
%                                                                     %   %%%
%     vector12=coordinate(iatom+1,:)-coordinate(iatom,:);             %   %%%
%     h_chiral(index1,index2)=...                                     %   %%%
%         mk_h(pp_sigma_C*exp(1i*phi),pp_pi_C*exp(1i*phi),vector12);  %   %%%
%     h_chiral(index2,index1)=...                                     %   %%%
%         mk_h(pp_sigma_C*exp(-1i*phi),pp_pi_C*exp(-1i*phi),vector12);%   %%%
%     h_chiral(index2,index2)=...                                     %   %%%
%         Bfield_C_chiral*(Sz/2+Lz)+SOC_chiral*hsoc;                  %   %%%
% end                                                                 %   %%%
% h_chiral(1:6,1:6)=Bfield_C_chiral*(Sz/2+Lz)+SOC_chiral*hsoc;        %   %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   %%%
%                                                                         %%%
%                                                                         %%%
% %%%%%%%%%%%%%%%%%%%%%% inter unit cell %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   %%%
% V_chiral=zeros(6*N,6*N);                                            %   %%%
% V_chiral(6*N-5:6*N,1:6)=...                                         %   %%%
%     mk_h(pp_sigma_C*exp(1i*phi),pp_pi_C*exp(1i*phi),...             %   %%%
%     coordinate(N+1,:)-coordinate(N,:));                             %   %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   %%%
%                                                                         %%% 
%                                                                         %%%
% %%%%%%%%%% calculating band structure of chiral molecule %%%%%%%%%%%%   %%%
% Kz_chiral=linspace(-pi,pi,1000);                                    %   %%%
% [Ek_chiral,Lz_chiral,Psik_chiral]=...                               %   %%%
%     chiral_bands(Kz_chiral,h_chiral,V_chiral);                      %   %%%
%                                                                     %   %%%
% % Ek_chiral: band dispersion relation                               %   %%%
% % Lz_chiral: orbital AM Lz distribution in k-space                  %   %%%
% % Psik_chiral: periodic part of wavefunction                        %   %%%
%                                                                     %   %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   %%%
%                                                                         %%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% Hamiltonian of SOC atoms %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
HC_SOC=zeros(L_SOC*6);                                                  %%%
for iatom =1:(L_SOC-1)                                                  %%%
    index1=6*(iatom-1)+1:6*(iatom);                                     %%%
    index2=6*(iatom)+1:6*(iatom+1);                                     %%%
                                                                        %%%
    HC_SOC(index1,index2)=...                                           %%%
        mk_h(pp_sigma_interface,pp_pi_interface,[0,0,1]);               %%%
    HC_SOC(index2,index1)=...                                           %%%
        mk_h(pp_sigma_interface,pp_pi_interface,[0,0,1]);               %%%
    HC_SOC(index2,index2)=SOC_nonchiral*hsoc+Bfield_C_SOC*(Sz/2);       %%%
end                                                                     %%%
HC_SOC(1:6,1:6)=SOC_nonchiral*hsoc+Bfield_C_SOC*(Sz/2);                 %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%% coupling between chiral molecule and SOC atoms %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
HC_SOC_chiral=zeros(6*L_SOC,6*(N*L_chiral+1));                          %%%
HC_SOC_chiral(6*L_SOC-5:6*L_SOC,1:6)...                                 %%%
    =mk_h(pp_sigma_interface,pp_pi_interface,[0,0,1]);                  %%%
HC_chiral_SOC=zeros(6*(N*L_chiral+1),6*L_SOC);                          %%%
HC_chiral_SOC(6*N*L_chiral+1:6*N*L_chiral+6,1:6)=...                    %%%
    mk_h(pp_sigma_interface,pp_pi_interface,[0,0,1]);                   %%%
HC_SOC_SOC=zeros(6*L_SOC,6*L_SOC);                                      %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% the whole Hamiltonian in scattering region %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
HC=[HC_SOC,        HC_SOC_chiral, HC_SOC_SOC;                           %%%
    HC_SOC_chiral',HC_chiral,     HC_chiral_SOC;                        %%%
    HC_SOC_SOC',   HC_chiral_SOC',HC_SOC];                              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% coupling between scattering region %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% and left lead %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
VCL=zeros(size(HC,1),6);                                                %%%
VCL(1:6,:)=mk_h(pp_sigma_L,pp_pi_L,[0,0,1]);                            %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% coupling between scattering region %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% and right lead %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
VCR=zeros(size(HC,1),6);                                                %%%
VCR(size(HC,1)-5:size(HC,1),:)=mk_h(pp_sigma_R,pp_pi_R,[0,0,1]);        %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





%% Calculating (spin/orbital/total) conductances
for iE=1:length(Energy)
    disp(['Calculating transmissions: ',num2str(iE/nE*100),'% ...'])
    E=Energy(iE);
    
    for iB=1:length(Bfield_L)
        B=Bfield_L(iB);
        H00_L=-B*Sz+0.00001*(Sz/2+Lz)+SOC_L*hsoc;         % onsite Hamiltonian of 
                                                          % left lead
        
        H01_L=mk_h(pp_sigma_L,pp_pi_L,[0,0,1]);           % intersite Hamiltonian 
                                                          % of left lead
                                                  
        H00_R=-B*Sz+0.00001*(Sz/2+Lz)+SOC_R*hsoc;         % onsite Hamiltonian of
                                                          % right lead
        
        H01_R=mk_h(pp_sigma_R,pp_pi_R,[0,0,1]);           % intersite Hamiltonian
                                                          % of right lead
        
        
        % -------- get surface retarded Green function (GF) of Left lead -----------
        [gsr_L,gbr_L]=surfGF_H(E,H00_L,H00_L,H01_L,H01_L',eye(size(H00_L)),200,eta0);
        
        % -------- get surface retarded Green function (GF) of right lead ----------
        [gsr_R,gbr_R]=surfGF_H(E,H00_L,H00_L,H01_L',H01_L,eye(size(H00_L)),200,eta0);
        
        gsa_L=gsr_L';    % surface advanced GF of left lead
        gsa_R=gsr_R';    % surface advanced GF of right lead
        
        
        
        
        % ----------- total conductance calculated by NEGF -------------
        Sigma_r_L=VCL*gsr_L*VCL';
        Sigma_r_R=VCR*gsr_R*VCR';
        Sigma_a_L=VCL*gsa_L*VCL';
        Sigma_a_R=VCR*gsa_R*VCR';
        
        Gamma_L=1i*(Sigma_r_L-Sigma_a_L);
        Gamma_R=1i*(Sigma_r_R-Sigma_a_R);
        
        W0r=(E+1i*eta)*eye(size(HC))-HC;
        W0a=(E-1i*eta)*eye(size(HC))-HC;
        WCr=W0r-Sigma_r_L-Sigma_r_R;
        WCa=W0a-Sigma_a_L-Sigma_a_R;
        
        GCr=eye(size(WCr))/WCr;
        GCa=eye(size(WCa))/WCa;
        
        G_total_NEGF(iE,iB)=trace(Gamma_R*GCr*Gamma_L*GCa);
        % ------------------ end NEGF method -----------------------
        
        
        
        % ------- total/orbital/spin conductance calculated by Smatrix --------
        
        % ------- get transmission and reflection matrices ---------
        [t,r,u_L_p,u_L_m,u_R_p,u_R_m]...
            =mk_t_matrix(E,H01_L,H00_L,H01_R,H00_R,HC,VCL,VCR,...
            gsr_L,gsr_R,gbr_L,gbr_R,eta);
        
        % t: the complex transmission amplitude matrix
        % r: the complex reflection amplitude matrix
        % u_L_p: normalized wavefunctions in the left lead with 
        %        positive group velocities
        % u_L_m: normalized wavefunctions in the left lead with 
        %        negative group velocities
        % u_R_p: normalized wavefunctions in the right lead with 
        %        positive group velocities
        % u_R_m: normalized wavefunctions in the right lead with 
        %        negative group velocities
        
        % -------- transmission and reflection by S-matrix --------
        Xi_Smatrix(iE,iB)=trace(t'*t);  % total transmission amplitude
        
        if ~isempty(u_L_p) && ~isempty(u_R_p)
            Sxnm_R=u_R_p'*Sx*u_R_p;
            Synm_R=u_R_p'*Sy*u_R_p;
            Sznm_R=u_R_p'*Sz*u_R_p;
            
            Lxnm_R=u_R_p'*Lx*u_R_p;
            Lynm_R=u_R_p'*Ly*u_R_p;
            Lznm_R=u_R_p'*Lz*u_R_p;
            
            Xi_Sx_R(iE,iB)=...               % spin-x component
                trace(t*diag(diag(Sxnm_R))*t');   % transmission
            
            Xi_Sy_R(iE,iB)=...               % spin-y component
                trace(t*diag(diag(Synm_R))*t');   % transmission 
            
            Xi_Sz_R(iE,iB)=...               % spin-z component
                trace(t*diag(diag(Sznm_R))*t');   % transmission 
            
            Xi_Lx_R(iE,iB)=...               % orbital-x component
                trace(t*diag(diag(Lxnm_R))*t');   % transmission 
            
            Xi_Ly_R(iE,iB)=...               % orbital-y component
                trace(t*diag(diag(Lynm_R))*t');   % transmission 
            
            Xi_Lz_R(iE,iB)=...               % orbital-z component
            trace(t*diag(diag(Lznm_R))*t');       % transmission
        end
        
        Re_Smatrix(iE,iB)=trace(r'*r);     % total reflection amplitude
        
        % ---------- end S-matrix -------------
    end
end

PSz(:,1)=Xi_Sz_R(:,1)./Xi_Smatrix(:,1);
PLz(:,1)=Xi_Lz_R(:,1)./Xi_Smatrix(:,1);


%% plot chiral band and conductances
figure
hold on
for iB=1:(length(Bfield_L)/2)
    LineWidth=0.1+2*Bfield_L(2*iB-1);
    plot(Energy,real(G_total_NEGF(:,2*iB)-G_total_NEGF(:,2*iB-1)),'b',...
        'LineWidth',LineWidth)
end
title('NEGF')
xlabel('Energy (eV)')
ylabel('\Delta G (e^2/h)')
legend('M=0','M=0.2','M=0.4','M=0.6','M=0.8','M=1.0')

figure
hold on
for iB=1:(length(Bfield_L)/2)
    LineWidth=0.1+2*Bfield_L(2*iB-1);
    plot(Energy,real(Xi_Smatrix(:,2*iB)-Xi_Smatrix(:,2*iB-1)),'b',...
        'LineWidth',LineWidth)
end
title('Smatrix')
xlabel('Energy (eV)')
ylabel('\Delta G (e^2/h)')
legend('M=0','M=0.2','M=0.4','M=0.6','M=0.8','M=1.0')











%% functions used in this code


function [tnm,rnm,u_L_p,u_L_m,u_R_p,u_R_m]=...
    mk_t_matrix(E,H01_L,H00_L,H01_R,H00_R,HC,VCL,VCR,...
    gsr_L,gsr_R,gbr_L,gbr_R,eta)
    
    % ---------------- AL BL AR BR ---------------------
    [AL,BL,AR,BR]=mk_AB(E,H01_L,H00_L,H01_R,H00_R);
    % -------------- end AL BL AR BR -------------------
    
    
    
    % -------------- G_{S+1,0} -------------------------
    sigma_r_L=H01_L*gsr_L*H01_L';
    sigma_r_R=H01_R*gsr_R*H01_R';
    
    HLL=H00_L+sigma_r_L;
    HLC=VCL';
    HLR=zeros(size(H00_L,1),size(H00_R,2));
    
    HCL=VCL;
    HCC=HC;
    HCR=VCR;
    
    HRL=HLR';
    HRC=VCR';
    HRR=H00_R+sigma_r_R;
    
    H=[HLL,HLC,HLR;...
       HCL,HCC,HCR;...
       HRL,HRC,HRR];
    Wr_tot=(E+1i*eta)*eye(size(H))-H;
    Gr_tot=eye(size(Wr_tot))/Wr_tot;
    
    index_N=size(H,1)-5:size(H,1);
    index_0=1:6;
    
    GN0=Gr_tot(index_N,index_0);
    G00=Gr_tot(index_0,index_0);
    % ------------ end G_{S+1,0} -----------------------
    
    
    
    %---------------- lambda_L, lambda_R ----------------
    [UL,OL]=eig(AL,BL);
    [UR,OR]=eig(AR,BR);
    
    [lambda_L_p,v_L_p,u_L_p,lambda_L_m,v_L_m,u_L_m,uu_L_p,uu_L_m]...
        =mk_uvR(UL,OL,H01_L',eta);
    [lambda_R_p,v_R_p,u_R_p,lambda_R_m,v_R_m,u_R_m,uu_R_p,uu_R_m]...
        =mk_uvR(UR,OR,H01_R,eta);
    %
    
    %}
    
%     u_R=[u_R_p,u_R_m];
%     u_LL=[u1_LL,u2_LL];
%     uu_R_new=eye(length(v_R_p)+length(v_R_m))/u_R;
%     uu_LL_new=eye(length(v1_LL)+length(v2_LL))/u_LL;
    %-------------- end lambda_L, lambda_R -------------
    
    
    
    % --------------- Transmission --------------------
    if isempty(u_L_p)==1
        tnm=[];
        rnm=[];
    else
        tnm=zeros(length(v_L_p),length(v_R_p));
        rnm=zeros(length(v_L_p),length(v_L_m));
    
    for j=1:length(v_L_p)
        for k=1:length(v_R_p)
            tnm(j,k)=sqrt(v_R_p(k)/v_L_p(j))...
                *uu_R_p(k,:)*GN0/gbr_L*u_L_p(:,j);
        end
        
        for k=1:length(v_L_m)
            rnm(j,k)=sqrt(v_L_m(k)/v_L_p(j))...
                *uu_L_m(k,:)*(G00/gbr_L-eye(6))*u_L_p(:,j);
        end
    end
    end
    
    
end


function [AL,BL,AR,BR]=mk_AB(E,V_left,Hb_left,V_right,Hb_right)

ML=length(Hb_left);
MR=length(Hb_right);

AL=[V_left, Hb_left; zeros(ML), eye(ML)];
BL=[E*eye(ML), -V_left'; eye(ML), zeros(ML)];

AR=[V_right', Hb_right; zeros(MR), eye(MR)];
BR=[E*eye(MR), -V_right; eye(MR), zeros(MR)];

end


function [lambda_p,v_p,u_p,lambda_m,v_m,u_m,uu_p,uu_m]=mk_uvR(U,O,V,eta)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

u=U(1:length(U)/2,:);                    % get ui
% ------------- normalize ui ----------------
for i=1:length(u)
    u(:,i)=u(:,i)/sqrt(u(:,i)'*u(:,i));
end
% ---------- end normalize ui -------------

o=diag(O);
v=zeros(length(o),1);

index_p=[];
index_m=[];


for i=1:length(o)
    v(i)=-imag(o(i)*u(:,i)'*V*u(:,i));
    if abs(abs(o(i))-1)<eta && v(i)>0
        index_p=[index_p,i];
    end
end


for i=1:length(o)
    if abs(abs(o(i))-1)<eta && v(i)<0
        index_m=[index_m,i];
    end
end

if isempty(index_p)==0
lambda_p=o(index_p);
v_p=v(index_p);
for i=1:length(index_p)
    u_p(:,i)=u(:,index_p(i));
end
else
    lambda_p=[];
    v_p=[];
    u_p=[];
end

if isempty(index_m)==0
lambda_m=o(index_m);
v_m=v(index_m);
for i=1:length(index_m)
    u_m(:,i)=u(:,index_m(i));
end
else
    lambda_m=[];
    v_m=[];
    u_m=[];
end


uu_p=pinv(u_p);
uu_m=pinv(u_m);

end


function h = mk_h(pps,ppp,v)

e=v/sqrt(v*v');

x=e(1);
y=e(2);
z=e(3);

hs = pps*[x^2, x*y, x*z;...
          y*x, y^2, y*z;...
          z*x, z*y, z*z];
hp = ppp*[1-x^2, -x*y, -x*z;...
           -y*x,1-y^2, -y*z;...
           -z*x, -z*y,1-z^2];
h = hs + hp;

h = kron(h,eye(2));

end


function [ Gs,Gb ] = surfGF_H( omega,Hs,Hb,alpha,beta,A,p,q )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
[m,~]=size(Hs);
Ws0=(omega+q*1i)*A-Hs;
Wb0=(omega+q*1i)*A-Hb;
alpha0=alpha;
beta0=beta;

for i=1:p
    Ws1=Ws0-alpha0/Wb0*beta0;
    Wb1=Wb0-alpha0/Wb0*beta0-beta0/Wb0*alpha0;
    alpha1=alpha0/Wb0*alpha0;
    beta1=beta0/Wb0*beta0;
    
    Ws0=Ws1;
    Wb0=Wb1;
    alpha0=alpha1;
    beta0=beta1;
end

Gs=eye(m)/Ws1;
Gb=eye(m)/Wb1;

end









