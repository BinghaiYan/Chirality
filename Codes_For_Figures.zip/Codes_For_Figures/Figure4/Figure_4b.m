clear
clc


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%% Author: Yizhou Liu   (  yizhou.liu@weizmann.ac.il )                 %%%
%%%         (Weizmann Institute of Science)                             %%%
%%% This MatLab script calculates the chirality induced spin/orbital/   %%%
%%% total conductance in chiral DNA-like materials by both the          %%%
%%% nonequilibrium Green's Functions (NEFG) and scattering matrix methods%%
%%% binding method                                                      %%%
%%%                                                                     %%%
%%% Any usage of adaptation this script in paraperation for some        %%%
%%% manuscript are recommended to cite:                                 %%%
%%% Y. Liu, J. Xiao, J. Koo, and B. Yan,                                %%%
%%% Chirality driven topological electronic structure of DNA-like materials
%%% arXiv:2008.08881, 2020.                                             %%%
%%%                                                                     %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% input parameters

tL=1.3;  % isotropic hopping in the leads

L=2;     % number of unit cells of achiral molecule

L_SOC=1; % number of SOC atoms

t_interface=0.6; % isotropic hopping between the SOC atoms and the leads

pp_sigma_C1=1.0; % 1st sigma hopping of the achiral molecule

pp_pi_C1=-0.4;   % 1st pi hopping of the achiral molecule

pp_sigma_C2=1.0; % 2nd sigma hopping of the achiral molecule

pp_pi_C2=-0.4;   % 2nd pi hopping of the achiral molecule

pp_sigma_C3=0.2; % 3rd sigma hopping of the achiral molecule

pp_pi_C3=-0.1;   % 3rd pi hopping of the achiral molecule

SOC=0.5;         % SOC strength of the SOC atoms



%% calculating achiral bands and Lx orbital texture


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% spin and orbital angular momentum (AM) %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% matrix in basis of pxyz orbitals %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
l0=eye(3);                                                              %%%
lz=[0,-1i,0;...                                                         %%%
   1i, 0 ,0;...                                                         %%%
   0 , 0 ,0];                                                           %%%
lx=[0,0,0;...                                                           %%%
    0,0,-1i;...                                                         %%%
    0,1i,0];                                                            %%%
ly=[0,0,1i;...                                                          %%%
    0,0,0;...                                                           %%%
   -1i,0,0];                                                            %%%
                                                                        %%%
s0=eye(2);                                                              %%%
sz=[1,0;0,-1];                                                          %%%
sx=[0,1;1,0];                                                           %%%
sy=[0,-1i;1i,0];                                                        %%%
                                                                        %%%
L0=kron(l0,s0);                                                         %%%
Lx=kron(lx,s0);                                                         %%%
Ly=kron(ly,s0);                                                         %%%
Lz=kron(lz,s0);                                                         %%%
                                                                        %%%
S0=kron(l0,s0);                                                         %%%
Sx=kron(l0,sx);                                                         %%%
Sy=kron(l0,sy);                                                         %%%
Sz=kron(l0,sz);                                                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% SOC Hamiltonian in pxyz basis %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hsoc=[0*s0 -1i*sz  1i*sy;...                                            %%%
     1i*sz   0*s0 -1i*sx;...                                            %%%
    -1i*sy  1i*sx   0*s0];                                              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% make up of Hamiltonian in the achiral %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% molecule within one unit cell %%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h0=zeros(12,12);                                                        %%%
V =zeros(12,12);                                                        %%%
                                                                        %%%
h0(1:6,7:12)=mk_h(pp_sigma_C1,pp_pi_C1,[0,1,sqrt(3)]);                  %%%
h0(7:12,1:6)=h0(1:6,7:12)';                                             %%%
                                                                        %%%
V(1:6,1:6)=mk_h(pp_sigma_C3,pp_pi_C3,[0,0,1]);                          %%%
V(7:12,1:6)=mk_h(pp_sigma_C2,pp_pi_C2,[0,-1,sqrt(3)]);                  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% calculating achiral bands and orbital texture %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Kz=linspace(-pi,pi,1001)';                                              %%%
[Ek_achiral,Lxk,Psik]=achiral_bands(Kz,h0,V);                           %%%
                                                                        %%%
% Ek_achiral  : band dispersion relation                                %%%
% Lxk         : Lx distribution in k-space                              %%%
% Psik_achiral: periodic part of wavefunction                           %%%
                                                                        %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% plot achiral bands and orbital texture
figure
hold on
for iband=1:size(Ek_achiral,2)
    scatter(Kz/pi,Ek_achiral(:,iband),1,real(Lxk(:,iband)))
end
caxis([min(min(real(Lxk))),max(max(real(Lxk)))])
colormap(jet)
colorbar
ylim([-2 2])
ylabel('Energy')
title('Achiral band')
xticks([-1 0 1])
xticklabels({'-Z','\Gamma','Z'})
xlabel('k_z')






%% functions used in this script

function h = mk_h(pps,ppp,v)

e=v/sqrt(v*v');

x=e(1);
y=e(2);
z=e(3);

hs = pps*[x^2, x*y, x*z;...
          y*x, y^2, y*z;...
          z*x, z*y, z*z];
hp = ppp*[1-x^2, -x*y, -x*z;...
           -y*x,1-y^2, -y*z;...
           -z*x, -z*y,1-z^2];
h = hs + hp;

h = kron(h,eye(2));

end


function [Ek,Lxk,Psik]=achiral_bands(Kz,h_achiral,V_achiral)

lx=zeros(3);lx(2,3)=-1i;lx(3,2)=1i;
lx=kron(lx,eye(2));

Nsite=size(h_achiral,1)/6;

Lx=kron(eye(Nsite),lx);

Ek=zeros(length(Kz),length(h_achiral));
Lxk=Ek;
Psik=zeros(length(h_achiral),length(h_achiral),length(Kz));
for ik=1:length(Kz)
    kz=Kz(ik);
    Hk=h_achiral+V_achiral*exp(-1i*kz)+V_achiral'*exp(1i*kz);
    [U,O]=eig(Hk);
    [Ek(ik,:),index]=sort(real(diag(O)));
    for n=1:length(index)
        Lxk(ik,n)=U(:,index(n))'*Lx*U(:,index(n));
        Psik(:,n,ik)=U(:,index(n));
    end
end

end