clear
clc


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%% Author: Yizhou Liu   (  yizhou.liu@weizmann.ac.il )                 %%%
%%%         (Weizmann Institute of Science)                             %%%
%%% This MatLab script calculates the chirality induced spin/orbital/   %%%
%%% total conductance in chiral DNA-like materials by both the          %%%
%%% nonequilibrium Green's Functions (NEFG) and scattering matrix methods%%
%%% binding method                                                      %%%
%%%                                                                     %%%
%%% Any usage of adaptation this script in paraperation for some        %%%
%%% manuscript are recommended to cite:                                 %%%
%%% Y. Liu, J. Xiao, J. Koo, and B. Yan,                                %%%
%%% Chirality driven topological electronic structure of DNA-like materials
%%% arXiv:2008.08881, 2020.                                             %%%
%%%                                                                     %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% input parameters

tL=1.3;  % isotropic hopping in the leads

L=2;     % number of unit cells of achiral molecule

L_SOC=1; % number of SOC atoms

t_interface=0.6; % isotropic hopping between the SOC atoms and the leads

pp_sigma_C1=1.0; % 1st sigma hopping of the achiral molecule

pp_pi_C1=-0.4;   % 1st pi hopping of the achiral molecule

pp_sigma_C2=1.0; % 2nd sigma hopping of the achiral molecule

pp_pi_C2=-0.4;   % 2nd pi hopping of the achiral molecule

pp_sigma_C3=0.2; % 3rd sigma hopping of the achiral molecule

pp_pi_C3=-0.1;   % 3rd pi hopping of the achiral molecule

SOC=0.5;         % SOC strength of the SOC atoms

eta0=1e-10;      % dephasing parameter of the leads

eta =0.005;      % dephasing parameter of the scatter

Bfield_Leads=[0.6,-0.6];  % Magnetic moment of leads

% ------------ Energy range for transport calculation ---------------------
Emin=-2.2;
Emax= 2.2;
nE=1000;
Energy=linspace(Emin,Emax,nE)';
% --------------------- end Energy range ----------------------------------



%% make up of the tight-binding Hamiltonians

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% spin and orbital angular momentum (AM) %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% matrix in basis of pxyz orbitals %%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
l0=eye(3);                                                              %%%
lz=[0,-1i,0;...                                                         %%%
   1i, 0 ,0;...                                                         %%%
   0 , 0 ,0];                                                           %%%
lx=[0,0,0;...                                                           %%%
    0,0,-1i;...                                                         %%%
    0,1i,0];                                                            %%%
ly=[0,0,1i;...                                                          %%%
    0,0,0;...                                                           %%%
   -1i,0,0];                                                            %%%
                                                                        %%%
s0=eye(2);                                                              %%%
sz=[1,0;0,-1];                                                          %%%
sx=[0,1;1,0];                                                           %%%
sy=[0,-1i;1i,0];                                                        %%%
                                                                        %%%
L0=kron(l0,s0);                                                         %%%
Lx=kron(lx,s0);                                                         %%%
Ly=kron(ly,s0);                                                         %%%
Lz=kron(lz,s0);                                                         %%%
                                                                        %%%
S0=kron(l0,s0);                                                         %%%
Sx=kron(l0,sx);                                                         %%%
Sy=kron(l0,sy);                                                         %%%
Sz=kron(l0,sz);                                                         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% SOC Hamiltonian in pxyz basis %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hsoc=[0*s0 -1i*sz  1i*sy;...                                            %%%
     1i*sz   0*s0 -1i*sx;...                                            %%%
    -1i*sy  1i*sx   0*s0];                                              %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% make up of Hamiltonian in the achiral %%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%% molecule within one unit cell %%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h0=zeros(12,12);                                                        %%%
V =zeros(12,12);                                                        %%%
                                                                        %%%
h0(1:6,7:12)=mk_h(pp_sigma_C1,pp_pi_C1,[0,1,sqrt(3)]);                  %%%
h0(7:12,1:6)=h0(1:6,7:12)';                                             %%%
                                                                        %%%
V(1:6,1:6)=mk_h(pp_sigma_C3,pp_pi_C3,[0,0,1]);                          %%%
V(7:12,1:6)=mk_h(pp_sigma_C2,pp_pi_C2,[0,-1,sqrt(3)]);                  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%% make up of finite achiral molecule %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
H_achiral=zeros(12*L+6,12*L+6);                                         %%%
for i=1:L-1                                                             %%%
    index1=12*(i-1)+1:12*i;                                             %%%
    index2=12*i+1:12*(i+1);                                             %%%
    H_achiral(index2,index2)=h0;                                        %%%
    H_achiral(index1,index2)=V;                                         %%%
    H_achiral(index2,index1)=V';                                        %%%
end                                                                     %%%
H_achiral(1:12,1:12)=h0;                                                %%%
H_achiral(12*L-5:12*L,12*L+1:12*L+6)=...                                %%%
    mk_h(pp_sigma_C2,pp_pi_C2,[0,-1,sqrt(3)]);                          %%%
H_achiral(12*L+1:12*L+6,12*L-5:12*L)=...                                %%%
    mk_h(pp_sigma_C2,pp_pi_C2,[0,1,-sqrt(3)]);                          %%%
H_achiral(12*L-11:12*L-6,12*L+1:12*L+6)=...                             %%%
    mk_h(pp_sigma_C3,pp_pi_C3,[0,0,1]);                                 %%%
H_achiral(12*L+1:12*L+6,12*L-11:12*L-6)=...                             %%%
    mk_h(pp_sigma_C3,pp_pi_C3,[0,0,-1]);                                %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%% make up SOC parts %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% make up of whole scattering region %%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
V_interface=t_interface*eye(6);                                         %%%
H_SOC=SOC*kron(eye(L_SOC),hsoc)...                                      %%%
    +kron(diag(ones(L_SOC-1,1), 1),V_interface)...                      %%%
    +kron(diag(ones(L_SOC-1,1),-1),V_interface');                       %%%
H_SOC_achiral=zeros(size(H_SOC,2),size(H_achiral,1));                   %%%
H_SOC_achiral(size(H_SOC,2)-5:size(H_SOC,2),1:6)=V_interface;           %%%
H_SOC_SOC=zeros(size(H_SOC,2),size(H_SOC,1));                           %%%
H_achiral_SOC=zeros(size(H_achiral,2),size(H_SOC,1));                   %%%
H_achiral_SOC(size(H_achiral,2)-5:size(H_achiral,2),1:6)=V_interface;   %%%
HC=[H_SOC,         H_SOC_achiral, H_SOC_SOC;...                         %%%
    H_SOC_achiral',H_achiral,     H_achiral_SOC;...                     %%%
    H_SOC_SOC',    H_achiral_SOC',H_SOC];                               %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%% coupling between scatter region and leads %%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
VCL=zeros(size(HC,1),6);                                                %%%
VCL(1:6,:)=mk_h(tL,tL,[0,0,-1]);                                        %%%
VCR=zeros(size(HC,1),6);                                                %%%
VCR(size(HC,1)-5:size(HC,1),:)=mk_h(tL,tL,[0,0,-1]);                    %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% calculating spin/orbital/total conductances

for iE=1:length(Energy)
    E=Energy(iE);
    disp(['Calculating spin/orbital/total conductances: ',...
        num2str(iE*100/length(Energy)),'% ...'])
    for iB=1:length(Bfield_Leads)
        B=Bfield_Leads(iB);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%% make up of leads %%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        H00L=0.000011*Sx+0.000013*Lx-B*Sx;                              %%%
        H01L=mk_h(tL,tL,[0,0,-1]);                                      %%%
                                                                        %%%
        H00R=0.000011*Sx+0.000013*Lx-B*Sx;                              %%%
        H01R=mk_h(tL,tL,[0,0,1]);                                       %%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % --------- get surface ratarded Green function of leads ------
        [gsr_L,gbr_L]=surfGF_H(E,H00L,H00L,H01L,H01L',eye(size(H00L)),200,eta0);
        [gsr_R,gbr_R]=surfGF_H(E,H00R,H00R,H01R,H01R',eye(size(H00R)),200,eta0);
        
        % -------------------- advanced Green function ------------------------
        gsa_L=gsr_L';
        gsa_R=gsr_R';
        
        
        % ------------ total conductance calculated by NEGF -------------------
        Sigma_r_L=VCL*gsr_L*VCL';
        Sigma_r_R=VCR*gsr_R*VCR';
        Sigma_a_L=VCL*gsa_L*VCL';
        Sigma_a_R=VCR*gsa_R*VCR';
        
        Gamma_L=1i*(Sigma_r_L-Sigma_a_L);
        Gamma_R=1i*(Sigma_r_R-Sigma_a_R);
        
        W0r=(E+1i*eta)*eye(size(HC))-HC;
        W0a=(E-1i*eta)*eye(size(HC))-HC;
        WCr=W0r-Sigma_r_L-Sigma_r_R;
        WCa=W0a-Sigma_a_L-Sigma_a_R;
        
        GCr=eye(size(WCr))/WCr;
        GCa=eye(size(WCa))/WCa;
        
        G_total_NEGF(iE,iB)=trace(Gamma_R*GCr*Gamma_L*GCa);
        % ----------------------- end NEGF caculation ---------------------
        
        
        
        % ----- spin/orbital/total conductances calculated by Smatrix -----
        [t,r,u_L_p,u_L_m,u_R_p,u_R_m]...
            =mk_t_matrix(E,H01L,H00L,H01R,H00R,HC,VCL,VCR,...
            gsr_L,gsr_R,gbr_L,gbr_R,eta);
        
        % t: the complex transmission amplitude matrix
        % r: the complex reflection amplitude matrix
        % u_L_p: normalized wavefunctions in the left lead with positive group
        %        velocities
        % u_L_m: normalized wavefunctions in the left lead with negative group
        %        velocities
        % u_R_p: normalized wavefunctions in the right lead with positive group
        %        velocities
        % u_R_m: normalized wavefunctions in the right lead with negative group
        %        velocities
        
        % --- transmission and reflection calculated by S-matrix -----
        Xi_Smatrix(iE,iB)=trace(t'*t);  % total conductance
        
        if ~isempty(u_L_p) && ~isempty(u_R_p)
            Sxnm_R=u_R_p'*Sx*u_R_p;
            Synm_R=u_R_p'*Sy*u_R_p;
            Sznm_R=u_R_p'*Sz*u_R_p;
            
            Lxnm_R=u_R_p'*Lx*u_R_p;
            Lynm_R=u_R_p'*Ly*u_R_p;
            Lznm_R=u_R_p'*Lz*u_R_p;
            
            Xi_Sx_R(iE,iB)=...                     % spin-x component
                trace(t*diag(diag(Sxnm_R))*t');    % transmission
            
            Xi_Sy_R(iE,iB)=...                     % spin-y component
                trace(t*diag(diag(Synm_R))*t');    % transmission 
                
            Xi_Sz_R(iE,iB)=...                     % spin-z component 
                trace(t*diag(diag(Sznm_R))*t');    % transmission
            
            Xi_Lx_R(iE,iB)=...                     % orbital-x component 
                trace(t*diag(diag(Lxnm_R))*t');    % transmission
            
            Xi_Ly_R(iE,iB)=...                     % orbital-y component 
                trace(t*diag(diag(Lynm_R))*t');    % transmission
            
            Xi_Lz_R(iE,iB)=...                     % orbital-z component 
                trace(t*diag(diag(Lznm_R))*t');    % transmission
        end
        
        Re_Smatrix(iE,iB)=trace(r'*r);       % total reflection amplitude
        % ------------------ end S-matrix ------------------------------
    end
end





%% plot chiral band and conductances
figure
subplot(2,1,1)
hold on
plot(Energy,real(G_total_NEGF(:,2)-G_total_NEGF(:,1)),'r')
plot(Energy,real(Xi_Smatrix(:,2)-Xi_Smatrix(:,1)),'--m')
xlim([Emin Emax])
ylabel('\Delta G (e^2/h)')
legend('\Delta G (NEGF)','\Delta G (Smatrix)')
xlabel('Energy')

subplot(2,1,2)
hold on
plot(Energy,real(Xi_Lx_R(:,1)),'r','LineWidth',1)
plot(Energy,real(Xi_Lx_R(:,2)),'b','LineWidth',1)
xlabel('Conductances (e^2/h)')
xlim([Emin Emax])
ylabel('Energy')
legend('G_{L_x}(+M)','G_{L_x}(-M)')
title('Spin/Orbital/total conductances')










%% functions used in this script

function [tnm,rnm,u_L_p,u_L_m,u_R_p,u_R_m]=...
    mk_t_matrix(E,H01_L,H00_L,H01_R,H00_R,HC,VCL,VCR,...
    gsr_L,gsr_R,gbr_L,gbr_R,eta)
    
    % ---------------- AL BL AR BR ---------------------
    [AL,BL,AR,BR]=mk_AB(E,H01_L,H00_L,H01_R,H00_R);
    % -------------- end AL BL AR BR -------------------
    
    
    
    % -------------- G_{S+1,0} -------------------------
    sigma_r_L=H01_L*gsr_L*H01_L';
    sigma_r_R=H01_R*gsr_R*H01_R';
    
    HLL=H00_L+sigma_r_L;
    HLC=VCL';
    HLR=zeros(size(H00_L,1),size(H00_R,2));
    
    HCL=VCL;
    HCC=HC;
    HCR=VCR;
    
    HRL=HLR';
    HRC=VCR';
    HRR=H00_R+sigma_r_R;
    
    H=[HLL,HLC,HLR;...
       HCL,HCC,HCR;...
       HRL,HRC,HRR];
    Wr_tot=(E+1i*eta)*eye(size(H))-H;
    Gr_tot=eye(size(Wr_tot))/Wr_tot;
    
    index_N=size(H,1)-5:size(H,1);
    index_0=1:6;
    
    GN0=Gr_tot(index_N,index_0);
    G00=Gr_tot(index_0,index_0);
    % ------------ end G_{S+1,0} -----------------------
    
    
    
    %---------------- lambda_L, lambda_R ----------------
    [UL,OL]=eig(AL,BL);
    [UR,OR]=eig(AR,BR);
    
    [lambda_L_p,v_L_p,u_L_p,lambda_L_m,v_L_m,u_L_m,uu_L_p,uu_L_m]...
        =mk_uvR(UL,OL,H01_L',eta);
    [lambda_R_p,v_R_p,u_R_p,lambda_R_m,v_R_m,u_R_m,uu_R_p,uu_R_m]...
        =mk_uvR(UR,OR,H01_R,eta);
    %
    
    %}
    
%     u_R=[u_R_p,u_R_m];
%     u_LL=[u1_LL,u2_LL];
%     uu_R_new=eye(length(v_R_p)+length(v_R_m))/u_R;
%     uu_LL_new=eye(length(v1_LL)+length(v2_LL))/u_LL;
    %-------------- end lambda_L, lambda_R -------------
    
    
    
    % --------------- Transmission --------------------
    if isempty(u_L_p)==1
        tnm=[];
        rnm=[];
    else
        tnm=zeros(length(v_L_p),length(v_R_p));
        rnm=zeros(length(v_L_p),length(v_L_m));
    
    for j=1:length(v_L_p)
        for k=1:length(v_R_p)
            tnm(j,k)=sqrt(v_R_p(k)/v_L_p(j))...
                *uu_R_p(k,:)*GN0/gbr_L*u_L_p(:,j);
        end
        
        for k=1:length(v_L_m)
            rnm(j,k)=sqrt(v_L_m(k)/v_L_p(j))...
                *uu_L_m(k,:)*(G00/gbr_L-eye(6))*u_L_p(:,j);
        end
    end
    end
    
    
end


function [AL,BL,AR,BR]=mk_AB(E,V_left,Hb_left,V_right,Hb_right)

ML=length(Hb_left);
MR=length(Hb_right);

AL=[V_left, Hb_left; zeros(ML), eye(ML)];
BL=[E*eye(ML), -V_left'; eye(ML), zeros(ML)];

AR=[V_right', Hb_right; zeros(MR), eye(MR)];
BR=[E*eye(MR), -V_right; eye(MR), zeros(MR)];

end


function [lambda_p,v_p,u_p,lambda_m,v_m,u_m,uu_p,uu_m]=mk_uvR(U,O,V,eta)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

u=U(1:length(U)/2,:);                    % get ui
% ------------- normalize ui ----------------
for i=1:length(u)
    u(:,i)=u(:,i)/sqrt(u(:,i)'*u(:,i));
end
% ---------- end normalize ui -------------

o=diag(O);
v=zeros(length(o),1);

index_p=[];
index_m=[];


for i=1:length(o)
    v(i)=-imag(o(i)*u(:,i)'*V*u(:,i));
    if abs(abs(o(i))-1)<eta && v(i)>0
        index_p=[index_p,i];
    end
end


for i=1:length(o)
    if abs(abs(o(i))-1)<eta && v(i)<0
        index_m=[index_m,i];
    end
end

if isempty(index_p)==0
lambda_p=o(index_p);
v_p=v(index_p);
for i=1:length(index_p)
    u_p(:,i)=u(:,index_p(i));
end
else
    lambda_p=[];
    v_p=[];
    u_p=[];
end

if isempty(index_m)==0
lambda_m=o(index_m);
v_m=v(index_m);
for i=1:length(index_m)
    u_m(:,i)=u(:,index_m(i));
end
else
    lambda_m=[];
    v_m=[];
    u_m=[];
end


uu_p=pinv(u_p);
uu_m=pinv(u_m);

end


function h = mk_h(pps,ppp,v)

e=v/sqrt(v*v');

x=e(1);
y=e(2);
z=e(3);

hs = pps*[x^2, x*y, x*z;...
          y*x, y^2, y*z;...
          z*x, z*y, z*z];
hp = ppp*[1-x^2, -x*y, -x*z;...
           -y*x,1-y^2, -y*z;...
           -z*x, -z*y,1-z^2];
h = hs + hp;

h = kron(h,eye(2));

end


function [ Gs,Gb ] = surfGF_H( omega,Hs,Hb,alpha,beta,A,p,q )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
[m,~]=size(Hs);
Ws0=(omega+q*1i)*A-Hs;
Wb0=(omega+q*1i)*A-Hb;
alpha0=alpha;
beta0=beta;

for i=1:p
    Ws1=Ws0-alpha0/Wb0*beta0;
    Wb1=Wb0-alpha0/Wb0*beta0-beta0/Wb0*alpha0;
    alpha1=alpha0/Wb0*alpha0;
    beta1=beta0/Wb0*beta0;
    
    Ws0=Ws1;
    Wb0=Wb1;
    alpha0=alpha1;
    beta0=beta1;
end

Gs=eye(m)/Ws1;
Gb=eye(m)/Wb1;

end











